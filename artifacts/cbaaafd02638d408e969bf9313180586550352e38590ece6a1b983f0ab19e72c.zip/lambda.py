import json
import boto3

def lambda_handler(event, context):
    print("Hello from app1")


    return{
        'statuscode': 200,
        'body': json.dumps('Hello from Lambda!')
    }