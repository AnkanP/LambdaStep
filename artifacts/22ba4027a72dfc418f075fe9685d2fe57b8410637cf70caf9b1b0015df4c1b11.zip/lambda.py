import json
import boto3
import s3module

def prepare_query(event, context):
    state_input = event.get("input")
    BUCKET = state_input["bucket"]
    OBJ_KEY = state_input["objkey"]
    
    print(s3module.read_file_from_s3(BUCKET,OBJ_KEY))

    output = {
        "partition_sql": "partition",
        "merge_sql":      "merge"
    }


    return output